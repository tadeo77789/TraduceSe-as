const express = require('express');
const authController = require('../controllers/auth.controller');
const usersController = require('../controllers/Users.controller');
const authMiddleware = require('../middlewares/auth.middleware');

const router = express.Router();

router.post('/register', authController.register);
router.post('/login', authController.login);
router.get('/profile', authMiddleware, usersController.getProfile);

module.exports = router;